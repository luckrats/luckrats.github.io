---
layout: post
title: Vim 常用资源
category: 资源
tags: Vim
keywords: Vim
---

## 在粘贴代码时不启动自动缩进

粘贴之前输入 `:set paste`
粘贴完后恢复 `:set nopaste`

## 关闭和开启行号

关闭 `:set nonu`
开启 `:set number`

