---
layout: post
title: Bootstrap常用资源
category: 资源
tags: Bootstrap
description: 列举自己搜集的Bootstrap资源，给像我这样前端不太行的WEB开发者
---

### 官方资源

- [官方首页](http://twitter.github.io/bootstrap/)
  
### 字体图标

- [Font Awesome](http://fortawesome.github.io/Font-Awesome/)

  扩展bootstrap的图标，是基于css的，非常漂亮，而且还支持视网膜屏，但是貌似手机上没法支持（测试过UC）

### 下拉按钮

- [Bootstrap Mutiselect](http://davidstutz.github.io/bootstrap-multiselect/)

  多选下拉列表插件

### 表单扩展

- [Bootstrap Form Helpers](http://vincentlamanna.com/BootstrapFormHelpers/index.html)

  扩展常用的表单功能，包括日期选择、时间选择等

